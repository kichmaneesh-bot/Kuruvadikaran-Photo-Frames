package com.kuruvadikaran.photoframes

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private var verificationId: String? = null
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var selectedProduct: Product? = null
    private var selectedImage: Uri? = null

    private lateinit var status: TextView
    private lateinit var loginPanel: View
    private lateinit var shopPanel: View
    private lateinit var phoneInput: EditText
    private lateinit var otpInput: EditText
    private lateinit var sendOtpButton: Button
    private lateinit var verifyOtpButton: Button
    private lateinit var productsContainer: LinearLayout
    private lateinit var uploadButton: Button
    private lateinit var saveOrderButton: Button
    private lateinit var photoPreview: ImageView
    private lateinit var selectedText: TextView

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedImage = uri
            photoPreview.setImageURI(uri)
            photoPreview.visibility = View.VISIBLE
            saveOrderButton.isEnabled = true
            status.text = "Photo selected. Tap Save Order to upload and create the order."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        setupAuthUi()
        if (auth.currentUser != null) showShop() else showLogin()
    }

    private fun bindViews() {
        status = findViewById(R.id.status); loginPanel = findViewById(R.id.loginPanel); shopPanel = findViewById(R.id.shopPanel)
        phoneInput = findViewById(R.id.phoneInput); otpInput = findViewById(R.id.otpInput)
        sendOtpButton = findViewById(R.id.sendOtpButton); verifyOtpButton = findViewById(R.id.verifyOtpButton)
        productsContainer = findViewById(R.id.productsContainer); uploadButton = findViewById(R.id.uploadButton)
        saveOrderButton = findViewById(R.id.saveOrderButton); photoPreview = findViewById(R.id.photoPreview); selectedText = findViewById(R.id.selectedText)
        findViewById<Button>(R.id.signOutButton).setOnClickListener { auth.signOut(); showLogin() }
    }

    private fun setupAuthUi() {
        sendOtpButton.setOnClickListener { sendOtp() }
        verifyOtpButton.setOnClickListener { verifyOtp() }
        uploadButton.setOnClickListener { imagePicker.launch("image/*") }
        saveOrderButton.setOnClickListener { createOrder() }
    }

    private fun showLogin() {
        loginPanel.visibility = View.VISIBLE; shopPanel.visibility = View.GONE
        status.text = "Sign in with your mobile number"
    }

    private fun showShop() {
        loginPanel.visibility = View.GONE; shopPanel.visibility = View.VISIBLE
        status.text = "Loading frame sizes…"
        loadProducts()
    }

    private fun sendOtp() {
        val raw = phoneInput.text.toString().trim()
        val phone = if (raw.startsWith("+")) raw else "+91$raw"
        if (phone.length < 10) { phoneInput.error = "Enter a valid mobile number"; return }
        status.text = "Sending OTP…"
        sendOtpButton.isEnabled = false
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) { signIn(credential) }
                override fun onVerificationFailed(e: FirebaseException) { sendOtpButton.isEnabled = true; status.text = "OTP failed: ${e.message}" }
                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                    verificationId = id; resendToken = token; otpInput.visibility = View.VISIBLE; verifyOtpButton.visibility = View.VISIBLE; sendOtpButton.isEnabled = true; status.text = "OTP sent. Enter the 6-digit code."
                }
            }).build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private fun verifyOtp() {
        val id = verificationId ?: run { status.text = "Please request OTP first"; return }
        val code = otpInput.text.toString().trim()
        if (code.length != 6) { otpInput.error = "Enter 6-digit OTP"; return }
        signIn(PhoneAuthProvider.getCredential(id, code))
    }

    private fun signIn(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val user = auth.currentUser ?: return@addOnCompleteListener
                db.collection("users").document(user.uid).set(mapOf("phone" to user.phoneNumber, "updatedAt" to System.currentTimeMillis()), com.google.firebase.firestore.SetOptions.merge())
                showShop()
            } else status.text = "Sign-in failed: ${task.exception?.message}"
        }
    }

    private fun loadProducts() {
        db.collection("products").whereEqualTo("active", true).get().addOnSuccessListener { snap ->
            productsContainer.removeAllViews()
            val products = snap.documents.mapNotNull { d ->
                val price = d.getLong("price")?.toInt() ?: return@mapNotNull null
                Product(d.id, d.getString("size") ?: d.id, price, d.getString("name") ?: "Photo Frame")
            }.sortedBy { it.price }
            if (products.isEmpty()) {
                status.text = "No active products found in Firestore."
                return@addOnSuccessListener
            }
            status.text = "Choose a frame size"
            products.forEach { product ->
                val button = Button(this).apply {
                    text = "${product.name} • ${product.size} — ₹${product.price}"
                    setOnClickListener {
                        selectedProduct = product
                        selectedText.text = "Selected: ${product.name} (${product.size}) — ₹${product.price}"
                        uploadButton.isEnabled = true
                    }
                }
                productsContainer.addView(button)
            }
        }.addOnFailureListener { status.text = "Could not load products: ${it.message}" }
    }

    private fun createOrder() {
        val user = auth.currentUser ?: run { showLogin(); return }
        val product = selectedProduct ?: run { status.text = "Select a frame first"; return }
        val uri = selectedImage ?: run { status.text = "Choose a photo first"; return }
        saveOrderButton.isEnabled = false
        status.text = "Uploading photo…"
        Thread {
            try {
                val secureUrl = CloudinaryUploader.upload(this, uri)
                val order = hashMapOf<String, Any>(
                    "customerId" to user.uid,
                    "customerPhone" to (user.phoneNumber ?: ""),
                    "productId" to product.id,
                    "productName" to product.name,
                    "size" to product.size,
                    "total" to product.price,
                    "photoUrl" to secureUrl,
                    "status" to "Order placed",
                    "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )
                db.collection("orders").add(order).addOnSuccessListener { ref ->
                    runOnUiThread {
                        status.text = "Order saved successfully. Order ID: ${ref.id}"
                        saveOrderButton.isEnabled = true
                        selectedImage = null; photoPreview.visibility = View.GONE
                    }
                }.addOnFailureListener { e -> runOnUiThread { saveOrderButton.isEnabled = true; status.text = "Order save failed: ${e.message}" } }
            } catch (e: Exception) {
                runOnUiThread { saveOrderButton.isEnabled = true; status.text = e.message ?: "Photo upload failed" }
            }
        }.start()
    }

    data class Product(val id: String, val size: String, val price: Int, val name: String)
}
