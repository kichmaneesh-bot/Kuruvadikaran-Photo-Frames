package com.kuruvadikaran.photoframes

import android.content.Context
import android.net.Uri
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import org.json.JSONObject

object CloudinaryUploader {
    // Replace only CLOUD_NAME with the Cloudinary Cloud Name from your Cloudinary dashboard.
    private const val CLOUD_NAME = "YOUR_CLOUD_NAME"
    private const val UPLOAD_PRESET = "kuruvadikaran_customer_photos2"

    fun upload(context: Context, uri: Uri): String {
        require(CLOUD_NAME != "YOUR_CLOUD_NAME") { "Set your Cloudinary cloud name in CloudinaryUploader.kt" }
        val boundary = "----KPF${UUID.randomUUID()}"
        val connection = (URL("https://api.cloudinary.com/v1_1/$CLOUD_NAME/image/upload").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            doInput = true
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            connectTimeout = 30000
            readTimeout = 60000
        }
        DataOutputStream(connection.outputStream).use { out ->
            fun field(name: String, value: String) {
                out.writeBytes("--$boundary\r\n")
                out.writeBytes("Content-Disposition: form-data; name=\"$name\"\r\n\r\n")
                out.writeBytes("$value\r\n")
            }
            field("upload_preset", UPLOAD_PRESET)
            val resolver = context.contentResolver
            val fileName = "customer_${System.currentTimeMillis()}.jpg"
            out.writeBytes("--$boundary\r\n")
            out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"$fileName\"\r\n")
            out.writeBytes("Content-Type: ${resolver.getType(uri) ?: "image/jpeg"}\r\n\r\n")
            resolver.openInputStream(uri)?.use { input -> input.copyTo(out) } ?: error("Unable to read selected image")
            out.writeBytes("\r\n--$boundary--\r\n")
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) error("Cloudinary upload failed ($code): $body")
        return JSONObject(body).getString("secure_url")
    }
}
