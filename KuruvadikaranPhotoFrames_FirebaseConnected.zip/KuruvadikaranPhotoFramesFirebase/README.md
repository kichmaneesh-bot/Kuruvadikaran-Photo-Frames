# Kuruvadikaran Photo Frames — Firebase-connected Android project

Package: `com.kuruvadikaran.photoframes`
Firebase project: `kuruvadikaran-photo-frames`
Cloudinary upload preset: `kuruvadikaran_customer_photos2`

## Connected
- Firebase Phone Authentication with OTP
- Firestore `products` collection for frame sizes/prices
- Firestore `users` collection after login
- Cloudinary direct customer photo upload
- Firestore `orders` with `photoUrl`

## One required Cloudinary value
Open `app/src/main/java/com/kuruvadikaran/photoframes/CloudinaryUploader.kt` and replace:
`YOUR_CLOUD_NAME`
with your Cloudinary **Cloud name**. Do not put the Cloudinary API Secret in the Android app.

## Firebase phone-auth requirement
For Android phone authentication, add the app's SHA-256 certificate fingerprint in Firebase Console. Android Studio can show the debug SHA-256 from the Gradle signing report. The Firebase phone-auth documentation recommends adding SHA-256 and notes that Play Integrity is used for app verification on supported devices.

## Firestore
The included `firestore.rules` matches the production rules already configured in the Firebase project. Products are readable by authenticated users; customers can create/read only their own orders; clients cannot update/delete orders.

## Build
Open this folder in Android Studio, allow Gradle sync, then run the `app` configuration on an Android device/emulator.

This environment does not include a full Android SDK/build toolchain, so this source project is provided for Android Studio to compile/sign into an APK.
